document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("chatForm");
  const input = document.getElementById("chatInput");
  const messages = document.getElementById("chatMessages");
  const status = document.getElementById("chatStatus");
  const sendButton = document.getElementById("sendButton");
  let history = [];

  function addMessage(role, text) {
    const row = document.createElement("div");
    row.className = "chat-message " + role;
    const avatar = document.createElement("span");
    avatar.className = "message-avatar";
    avatar.textContent = role === "assistant" ? "✦" : "You";
    const bubble = document.createElement("div");
    bubble.className = "message-bubble";
    const p = document.createElement("p");
    p.textContent = text;
    bubble.appendChild(p);
    row.append(avatar, bubble);
    messages.appendChild(row);
    messages.scrollTop = messages.scrollHeight;
  }

  function demoAnswer(question) {
    const q = question.toLowerCase();
    if (q.includes("roadmap") || q.includes("learning plan") || q.includes("study plan")) {
      return "Here is a practical starter roadmap:\\n\\n1. Learn the syntax and core concepts.\\n2. Practise small exercises every day.\\n3. Learn arrays, strings, functions and common data structures.\\n4. Solve beginner problems, then gradually increase difficulty.\\n5. Build a small project and explain how it works.\\n6. Practise explaining your approach aloud.\\n\\nThis is a demo response, not a live AI answer. Connect the server to an AI API for tailored answers.";
    }
    if (q.includes("html") || q.includes("css") || q.includes("javascript") || q.includes("web")) {
      return "Quick web-development guide:\\n\\n• HTML defines the structure and content.\\n• CSS controls the appearance and layout.\\n• JavaScript adds behaviour and interactivity.\\n\\nExample: HTML creates a button, CSS styles it, and JavaScript responds when someone clicks it. Try building a small page that uses all three.";
    }
    if (q.includes("array")) {
      return "An array stores multiple values in an ordered collection. For example, in JavaScript: const scores = [80, 90, 75]; The first item is scores[0], because array indexes usually start at 0. You can loop through the array to process every score. Ask for a language-specific example to go deeper.";
    }
    if (q.includes("interview") || q.includes("star")) {
      return "A good interview preparation routine is: understand the problem, ask clarifying questions, explain your approach, write readable code, test edge cases and discuss time/space complexity. For behavioural questions, STAR means Situation, Task, Action and Result. Use real examples from your own projects and teamwork.";
    }
    if (q.includes("recursion")) {
      return "Recursion is when a function solves a problem by calling itself on a smaller version of that problem. It needs a base case to stop and a recursive case that makes progress. Think of counting down: if n is 0, stop; otherwise print n and call the function with n - 1. This is a demo explanation; an AI-connected tutor can tailor examples to your code.";
    }
    return "Thanks for your question! In demo mode I can show a few basic study examples, but I can't generate a fully tailored answer yet. To enable real AI answers, run LearnHub's Node server and set your API key as described in README.txt. You can also try asking about arrays, web development, recursion, interview preparation or a learning roadmap.";
  }

  async function getAnswer(question) {
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, history: history.slice(0, -1).slice(-8) })
      });
      if (!response.ok) throw new Error("AI service is not configured");
      const data = await response.json();
      if (!data.answer) throw new Error("Empty answer");
      status.textContent = "Connected to the AI Tutor.";
      return data.answer;
    } catch (error) {
      status.textContent = "Demo mode: add an API key and run server.js for real AI-generated answers.";
      return demoAnswer(question);
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const question = input.value.trim();
    if (!question || sendButton.disabled) return;
    addMessage("user", question);
    history.push({ role: "user", content: question });
    input.value = "";
    sendButton.disabled = true;
    sendButton.textContent = "Thinking…";
    status.textContent = "Working on your question…";
    const answer = await getAnswer(question);
    addMessage("assistant", answer);
    history.push({ role: "assistant", content: answer });
    sendButton.disabled = false;
    sendButton.textContent = "Send ↑";
    input.focus();
  });

  document.querySelectorAll("[data-prompt]").forEach(button => {
    button.addEventListener("click", () => {
      input.value = button.dataset.prompt;
      input.focus();
    });
  });

  document.getElementById("clearChat").addEventListener("click", () => {
    history = [];
    messages.innerHTML = '<div class="chat-message assistant"><span class="message-avatar">✦</span><div class="message-bubble"><b>Chat cleared.</b><p>What would you like to learn next?</p></div></div>';
    status.textContent = "Ready for your next question.";
  });

  const savedPrompt = sessionStorage.getItem("learnhubTutorPrompt");
  if (savedPrompt) { input.value = savedPrompt; sessionStorage.removeItem("learnhubTutorPrompt"); input.focus(); }

  // Enter sends; Shift+Enter creates a new line.
  input.addEventListener("keydown", event => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      form.requestSubmit();
    }
  });
});