document.addEventListener("DOMContentLoaded", () => {
  const search = document.getElementById("trackSearch");
  const cards = [...document.querySelectorAll(".track-card")];
  const filters = [...document.querySelectorAll("[data-track-filter]")];
  const empty = document.getElementById("noTracks");
  let category = "all";
  function update() {
    const q = search.value.toLowerCase().trim();
    let visible = 0;
    cards.forEach(card => {
      const match = (category === "all" || card.dataset.category === category) && card.textContent.toLowerCase().includes(q);
      card.classList.toggle("hidden", !match);
      if (match) visible++;
    });
    empty.classList.toggle("hidden", visible > 0);
  }
  search.addEventListener("input", update);
  filters.forEach(button => button.addEventListener("click", () => {
    category = button.dataset.trackFilter;
    filters.forEach(b => b.classList.toggle("active", b === button));
    update();
  }));
  document.querySelectorAll("[data-question]").forEach(button => button.addEventListener("click", () => {
    sessionStorage.setItem("learnhubTutorPrompt", button.dataset.question);
    window.location.href = "ai-tutor.html";
  }));
});