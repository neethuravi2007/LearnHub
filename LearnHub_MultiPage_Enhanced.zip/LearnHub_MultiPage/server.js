// LearnHub local server + optional AI Tutor API.
// Requires Node.js 18+. Keep OPENAI_API_KEY on the server, never in browser JavaScript.
const http = require("http");
const fs = require("fs");
const path = require("path");
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const MIME = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".txt":"text/plain; charset=utf-8", ".json":"application/json; charset=utf-8" };

function send(res, status, data, type="application/json; charset=utf-8") {
  res.writeHead(status, { "Content-Type": type, "X-Content-Type-Options": "nosniff" });
  res.end(typeof data === "string" ? data : JSON.stringify(data));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => { body += chunk; if (body.length > 20000) { reject(new Error("Request too large")); req.destroy(); } });
    req.on("end", () => { try { resolve(JSON.parse(body || "{}")); } catch { reject(new Error("Invalid JSON")); } });
    req.on("error", reject);
  });
}
function safeText(value, max=2000) { return typeof value === "string" ? value.slice(0, max) : ""; }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method === "POST" && url.pathname === "/api/chat") {
    if (!process.env.OPENAI_API_KEY) return send(res, 503, { error: "AI API key is not configured." });
    try {
      const body = await readBody(req);
      const question = safeText(body.question).trim();
      if (!question) return send(res, 400, { error: "Please enter a question." });
      const history = Array.isArray(body.history) ? body.history.slice(-8).map(item => ({
        role: item.role === "assistant" ? "assistant" : "user",
        content: safeText(item.content, 2000)
      })) : [];
      const input = history.concat([{ role: "user", content: question }]);
      const apiResponse = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-5-mini",
          instructions: "You are LearnHub's friendly educational tutor. Explain programming, computer science and interview preparation clearly for a beginner. Use short steps and examples. Do not claim certainty when unsure. For interview preparation, coach the learner rather than claiming there is one guaranteed path to a job.",
          input,
          max_output_tokens: 700
        })
      });
      const result = await apiResponse.json();
      if (!apiResponse.ok) {
        console.error("AI API error:", result.error?.message || apiResponse.status);
        return send(res, 502, { error: "The AI service could not answer. Check the API key, model access and account billing." });
      }
      const answer = (result.output || []).flatMap(item => item.content || []).filter(item => item.type === "output_text").map(item => item.text).join("\n").trim();
      if (!answer) return send(res, 502, { error: "The AI service returned an empty answer." });
      return send(res, 200, { answer });
    } catch (error) {
      console.error(error.message);
      return send(res, 500, { error: "Something went wrong while contacting the AI service." });
    }
  }
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, { error: "Method not allowed" });
  let requested = decodeURIComponent(url.pathname === "/" ? "/index.html" : url.pathname);
  let file = path.resolve(ROOT, "." + requested);
  if (!file.startsWith(ROOT + path.sep) && file !== path.join(ROOT, "index.html")) return send(res, 403, "Forbidden", "text/plain; charset=utf-8");
  fs.readFile(file, (error, content) => {
    if (error) return send(res, 404, "File not found", "text/plain; charset=utf-8");
    res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream", "X-Content-Type-Options": "nosniff" });
    res.end(req.method === "HEAD" ? undefined : content);
  });
});
server.listen(PORT, () => {
  console.log(`LearnHub is running at http://localhost:${PORT}`);
  console.log(process.env.OPENAI_API_KEY ? "AI Tutor API: configured" : "AI Tutor API: demo mode (set OPENAI_API_KEY for live answers)");
});