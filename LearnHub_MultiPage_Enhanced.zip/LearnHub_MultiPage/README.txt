LEARNHUB MULTI-PAGE WEBSITE — UPDATED VERSION

WHAT'S INCLUDED
- Existing course pages, study materials, video library and practice tests
- Skill Tracks page: C, C++, Java, Python, JavaScript, SQL, DSA, system design, CS fundamentals, portfolio and interview communication
- AI Tutor page: chat interface with demo responses, plus optional live AI answers through a server-side API
- Focus Timer: focus/short-break/long-break modes, custom durations, session counter, browser notifications, and a locally saved task
- Responsive styling for desktop and mobile

EASIEST WAY TO OPEN THE WEBSITE
1. Extract this ZIP file.
2. Open the LearnHub_MultiPage folder in VS Code.
3. If you only want to view the website, open index.html with Live Server.
   The Focus Timer and Skill Tracks work in the browser.
   The AI Tutor will use demo responses unless the Node.js server and API key are configured.

RUN THE LOCAL SERVER
1. Install Node.js 18 or newer.
2. Open the LearnHub_MultiPage folder in VS Code.
3. In VS Code, choose Terminal > New Terminal.
4. Run: node server.js
5. Open http://localhost:3000 in your browser.
   No npm install is required; the server uses Node.js built-in modules.

ENABLE REAL AI ANSWERS (OPTIONAL)
The chatbot is connected to the OpenAI Responses API through server.js. To use real AI answers, you need your own API key and API access. API usage may cost money and is subject to your account's limits.
Never paste your API key into ai-tutor.js or any HTML file.

Windows PowerShell (current terminal only):
$env:OPENAI_API_KEY="YOUR_API_KEY_HERE"
node server.js

Windows Command Prompt (current terminal only):
set OPENAI_API_KEY=YOUR_API_KEY_HERE
node server.js

You may set OPENAI_MODEL to a model available to your API account. The default in server.js is gpt-5-mini.
If no key is set, the AI Tutor still opens in demo mode and explains how to enable the live AI connection.

NOTES
- The API key stays on the server and is not sent to the browser.
- Don't publish server.js with a real API key embedded in it.
- AI answers can be incorrect; verify important technical information.
- The project does not include login, database storage or user accounts.
- Timer preferences and task text are saved locally in the browser.
