document.addEventListener("DOMContentLoaded", () => {
  const display = document.getElementById("timeDisplay");
  const label = document.getElementById("modeLabel");
  const subtext = document.getElementById("timerSubtext");
  const startPause = document.getElementById("startPause");
  const ring = document.getElementById("timerRing");
  const modes = [...document.querySelectorAll("[data-mode]")];
  const selects = {
    focus: document.getElementById("focusMinutes"),
    short: document.getElementById("shortMinutes"),
    long: document.getElementById("longMinutes")
  };
  const names = { focus: "FOCUS SESSION", short: "SHORT BREAK", long: "LONG BREAK" };
  let mode = "focus";
  let remaining = Number(selects.focus.value) * 60;
  let timer = null;
  let endAt = null;
  let completed = Number(localStorage.getItem("learnhubFocusSessions") || 0);

  const fmt = secs => String(Math.floor(secs / 60)).padStart(2, "0") + ":" + String(secs % 60).padStart(2, "0");
  function render() {
    display.textContent = fmt(remaining);
    label.textContent = names[mode];
    subtext.textContent = mode === "focus" ? "One task. One session." : "Take a proper pause.";
    startPause.textContent = timer ? "Pause timer Ⅱ" : (remaining === Number(selects[mode].value) * 60 ? (mode === "focus" ? "Start focus" : "Start break") : "Resume timer ▶");
    ring.style.setProperty("--progress", (remaining / (Number(selects[mode].value) * 60) * 100) + "%");
    document.title = fmt(remaining) + " · LearnHub Focus";
    document.getElementById("sessionCount").textContent = completed;
  }
  function stopTimer() { if (timer) clearInterval(timer); timer = null; endAt = null; }
  function setMode(nextMode) {
    stopTimer();
    mode = nextMode;
    remaining = Number(selects[mode].value) * 60;
    modes.forEach(button => button.classList.toggle("active", button.dataset.mode === mode));
    render();
  }
  function tick() {
    remaining = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
    if (remaining <= 0) {
      stopTimer();
      if (mode === "focus") {
        completed++;
        localStorage.setItem("learnhubFocusSessions", String(completed));
      }
      render();
      subtext.textContent = mode === "focus" ? "Session complete. Take a break!" : "Break complete. Ready when you are.";
      startPause.textContent = "Start again";
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification(mode === "focus" ? "Focus session complete!" : "Break complete!", { body: mode === "focus" ? "Nice work. Take a short break." : "You're ready for your next session." });
      } else {
        alert(mode === "focus" ? "Focus session complete! Take a short break." : "Break complete! Ready when you are?");
      }
    } else render();
  }
  startPause.addEventListener("click", async () => {
    if (timer) {
      stopTimer();
      render();
      return;
    }
    if (remaining <= 0) remaining = Number(selects[mode].value) * 60;
    if ("Notification" in window && Notification.permission === "default") {
      try { await Notification.requestPermission(); } catch (_) {}
    }
    endAt = Date.now() + remaining * 1000;
    timer = setInterval(tick, 250);
    render();
  });
  document.getElementById("resetTimer").addEventListener("click", () => {
    stopTimer();
    remaining = Number(selects[mode].value) * 60;
    render();
  });
  modes.forEach(button => button.addEventListener("click", () => setMode(button.dataset.mode)));
  Object.entries(selects).forEach(([key, select]) => select.addEventListener("change", () => {
    if (key === mode) {
      stopTimer();
      remaining = Number(select.value) * 60;
      render();
    }
  }));
  document.getElementById("resetSessions").addEventListener("click", () => {
    completed = 0;
    localStorage.setItem("learnhubFocusSessions", "0");
    render();
  });
  const task = document.getElementById("focusTask");
  task.value = localStorage.getItem("learnhubFocusTask") || "";
  task.addEventListener("input", () => localStorage.setItem("learnhubFocusTask", task.value));
  render();
});